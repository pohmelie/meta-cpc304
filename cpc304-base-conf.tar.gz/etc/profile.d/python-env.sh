export BUILD_SYS=x86_64-linux
export HOST_SYS=i586-poky-linux
export STAGING_LIBDIR=/usr/lib
export STAGING_INCDIR=/usr/include
