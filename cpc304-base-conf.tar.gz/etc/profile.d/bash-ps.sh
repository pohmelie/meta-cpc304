export PS1="[\[$(tput setaf 6)\]\u \[$(tput setaf 2)\]\w\[$(tput setaf 7)\]]\[$(tput setaf 3)\]\\$\[$(tput sgr0)\] "
